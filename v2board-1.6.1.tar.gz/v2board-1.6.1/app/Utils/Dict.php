<?php

namespace App\Utils;

class Dict
{
    CONST EMAIL_WHITELIST_SUFFIX_DEFAULT = [
        'gmail.com',
        'qq.com',
        '163.com',
        'yahoo.com',
        'sina.com',
        '126.com',
        'outlook.com',
        'yeah.net',
        'foxmail.com'
    ];
    CONST WITHDRAW_METHOD_WHITELIST_DEFAULT = [
        '支付宝',
        'USDT',
        'Paypal'
    ];
}
